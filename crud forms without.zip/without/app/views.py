from .models import *
from django.shortcuts import redirect,HttpResponse,render
from django.urls import path


def create(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        roll = request.POST['roll']
        section = request.POST['section']
        Student(name=name,
                email=email,
                roll_number = roll,
                section =section).save()
        return redirect('read')
    return render(request,'create.html')


def read(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        roll = request.POST['roll']
        section = request.POST['section']
        Student(name=name,
                email=email,
                roll_number = roll,
                section =section).save()
        return redirect('read')
 
    data = Student.objects.all()
    return render(request,'read.html',{'data':data})

def update(request,id):
    dataget = Student.objects.get(id = id)
    data = Student.objects.all()
    if request.method == "POST":
        name = request.POST['name']
        email = request.POST['email']
        roll = request.POST['roll']
        section = request.POST['section']
        dataget.name = name
        dataget.email = email
        dataget.roll_number = roll
        dataget.section = section
        dataget.save()
        return redirect('read')
    return render(request,'update.html',{'dataget':dataget,'data':data})

def delete(request,id):
    dataget = Student.objects.get(id=id)
    dataget.delete()
    return redirect('read')
