from django.shortcuts import render,HttpResponse,redirect
from .forms import Myform
from .models import student
def myfun(request): 
    if request.method == 'POST':
        data= Myform(request.POST)
        data.save()
        # return HttpResponse('save successfully!!!')
        return redirect('Dashboard')
    else:
        data = Myform()
        return render(request,'first.html',{'data':data})
def dashboard(request):
    data=student.objects.all()
    return render (request,'dashboard.html',{'data':data})

def delete_data(request,key):
    data=student.objects.get(id=key)
    data.delete()
    return redirect('Dashboard')

def edit(request,key):
    data = student.objects.get(id = key)
    if request.method == 'POST':
        data= Myform(request.POST,instance=data)
        data.save()
        return redirect('Dashboard')
    else:
        fm=Myform(instance=data)
    return render(request,'edit.html',{'data':fm})

def update(request,key):
    data = student.objects.get(id = key)
    if request.method == 'POST':
        data=Myform(request.POST,instance=data)
        data.save()
        return redirect('Dashboard')
    else:
        data=Myform(instance=data)
        return render(request,'edit.html',{'data':data})







# def new(request):

    