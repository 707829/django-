from django.urls import path,include
from Myapp import views

urlpatterns = [
    path('',views.myfun,name="fun"),
    path('d',views.dashboard,name="Dashboard"),
    path('delete/<int:key>',views.delete_data,name="delete"),
    path('e/<int:key>',views.update,name="edit"),
]
